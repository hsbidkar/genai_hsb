# Foundations on Generative AI Course


## All content is copyright Data Trainers LLC and is intended to be used for educational purposes alone

